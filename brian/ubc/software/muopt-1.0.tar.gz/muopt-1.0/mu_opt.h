// mu_opt.h    -*- c++ -*-

#ifndef MU_OPT_H
#define MU_OPT_H

//#include "mu_opt_base.h"
//#include "mu_opt_ste.h"
//#include "mu_opt_stmt.h"
//#include "mu_opt_decl.h"
//#include "mu_opt_rule.h"
#include "mu_opt_root.h"

#endif /* MU_OPT_H */
