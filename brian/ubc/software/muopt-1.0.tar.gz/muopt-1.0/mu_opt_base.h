// mu_opt_base.h    -*- c++ -*-

#ifndef MU_OPT_BASE_H
#define MU_OPT_BASE_H

#include <mu.h>
#include <iostream.h>
#include <list>
#include <set>

//#define MUOPT_DEBUG

typedef unsigned int uint;
typedef set<int> ScopeSet;

class MuOptObject;

typedef struct {
  void        *node;  // new child Murphi object
  MuOptObject *obj;   // new child muopt object
} OptRet;


class MuOptObject {
public:
  MuOptObject(const char *name = NULL);
  virtual ~MuOptObject();

  const char *name() const { return _name; }

  virtual void displayTree(ostream& out, uint indent) const = 0;
  virtual ScopeSet *deps(uint reqNum = 0) const = 0;
  virtual OptRet optimize();

  int depLoop(uint reqNum) const;
  static uint nextReqNum() { return ++_thisReqNum; }

  static void indentLine(ostream& out, uint indent);

private:
  char *_name;
  mutable uint _lastReqNum;
  static uint _thisReqNum;
};

#endif /* MU_OPT_BASE_H */
