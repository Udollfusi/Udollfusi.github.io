// mu_opt_decl.cc    -*- c++ -*-

#include "mu_opt_decl.h"
#include "mu_opt_param.h"
#include "mu_opt_typedecl.h"


map<decl*,MuOptDecl*> MuOptDecl::_existing;


MuOptDecl::~MuOptDecl() {
}

MuOptDecl *MuOptDecl::newMuOptDecl(decl *d) {
  MuOptDecl *result = NULL;
  if(d)
    if(_existing.find(d) == _existing.end()) {
      switch(d->getclass()) {
      case decl::Type:
        result=MuOptTypeDecl::newMuOptTypeDecl(dynamic_cast<typedecl*>(d));
        break;
      case decl::Const:
        result = new MuOptDeclConst(dynamic_cast<constdecl*>(d));
        break;
      case decl::Var:
        result = new MuOptDeclVar(dynamic_cast<vardecl*>(d));
        break;
      case decl::Alias:
        result = new MuOptDeclAlias(dynamic_cast<aliasdecl*>(d));
        break;
      case decl::Quant:
        result = new MuOptDeclQuant(dynamic_cast<quantdecl*>(d));
        break;
      case decl::Choose:
        result = new MuOptDeclChoose(dynamic_cast<choosedecl*>(d));
        break;
      case decl::Param:
        result = MuOptParam::newMuOptParam(dynamic_cast<param*>(d));
        break;
      case decl::Proc:
        result = new MuOptDeclProc(dynamic_cast<procdecl*>(d));
        break;
      case decl::Func:
        result = new MuOptDeclFunc(dynamic_cast<funcdecl*>(d));
        break;
      case decl::Error_decl:
        result = new MuOptDeclError(dynamic_cast<error_decl*>(d));
        break;
      default:
        assert(0);
      }
      _existing[d] = result;
    } else {
      result = _existing[d];
#ifdef MUOPT_DEBUG
      cerr << "reissuing existing decl\n";
#endif
    }
  return result;
}


MuOptDeclConst::MuOptDeclConst(constdecl *n)
  : MuOptDecl(Const, n ? n->name : NULL), _node(n), _typed(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclConst::MuOptDeclConst(constdecl*)\n";
#endif
  //if(n && n->gettype())
  //  _typed = MuOptTypeDecl::newMuOptTypeDecl(n->gettype());
}

MuOptDeclConst::~MuOptDeclConst() {
  //delete _typed;
}

void MuOptDeclConst::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclConst::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Const \"" << name() << "\"\n";
  if(_typed) {
    indentLine(out, indent + 1);
    out << "[typed]\n";
    _typed->displayTree(out, indent + 2);
  }
}

ScopeSet *MuOptDeclConst::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  if(_typed)
    result = _typed->deps(reqNum);
  else
    result = new ScopeSet;

  //temp = .deps(reqNum);
  //result->insert(temp->begin(), temp->end());
  //delete temp;

  return result;
}


MuOptDeclVar::MuOptDeclVar(vardecl *n)
  : MuOptDecl(Var, n ? n->name : NULL), _node(n), _typed(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclVar::MuOptDeclVar(vardecl*)\n";
#endif
  //if(n && n->gettype())
  //  _typed = MuOptTypeDecl::newMuOptTypeDecl(n->gettype());
}

MuOptDeclVar::~MuOptDeclVar() {
  //delete _typed;
}

void MuOptDeclVar::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclVar::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Var \"" << name() << "\"\n";
  if(_typed) {
    indentLine(out, indent + 1);
    out << "[typed]\n";
    _typed->displayTree(out, indent + 2);
  }
}

ScopeSet *MuOptDeclVar::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  if(_typed)
    result = _typed->deps(reqNum);
  else
    result = new ScopeSet;

  //temp = .deps(reqNum);
  //result->insert(temp->begin(), temp->end());
  //delete temp;

  return result;
}


MuOptDeclAlias::MuOptDeclAlias(aliasdecl *n)
  : MuOptDecl(Alias, n ? n->name : NULL), _node(n),
    _ref(n ? n->getexpr() : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclAlias::MuOptDeclAlias(aliasdecl*)\n";
#endif
}

MuOptDeclAlias::~MuOptDeclAlias() {
}

void MuOptDeclAlias::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclAlias::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Alias \"" << name() << "\"\n";
  indentLine(out, indent + 1);
  out << "ref\n";
  _ref.displayTree(out, indent + 2);
}

ScopeSet *MuOptDeclAlias::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _ref.deps(reqNum);

  //temp = .deps(reqNum);
  //result->insert(temp->begin(), temp->end());
  //delete temp;

  return result;
}


MuOptDeclQuant::MuOptDeclQuant(quantdecl *n)
  : MuOptDecl(Quant, n ? n->name : NULL), _node(n), _typed(NULL),
    _left(n ? n->left : NULL), _right(n ? n->right : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclQuant::MuOptDeclQuant(quantdecl*)\n";
#endif
  //if(n && n->type)
  //  _typed = MuOptTypeDecl::newMuOptTypeDecl(n->type);
}

MuOptDeclQuant::~MuOptDeclQuant() {
  //delete _typed;
}

void MuOptDeclQuant::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclQuant::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Quant \"" << name() << "\"\n";
  if(_typed) {
    indentLine(out, indent + 1);
    out << "[typed]\n";
    _typed->displayTree(out, indent + 2);
  }
}

ScopeSet *MuOptDeclQuant::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _left.deps(reqNum);

  temp = _right.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  if(_typed) {
    temp = _typed->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}


MuOptDeclChoose::MuOptDeclChoose(choosedecl *n)
  : MuOptDecl(Choose, n ? n->name : NULL), _node(n), _typed(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclChoose::MuOptDeclChoose(choosedecl*)\n";
#endif
  //if(n && n->type)
  //  _typed = MuOptTypeDecl::newMuOptTypeDecl(n->type);
}

MuOptDeclChoose::~MuOptDeclChoose() {
  //delete _typed;
}

void MuOptDeclChoose::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclChoose::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Choose \"" << name() << "\"\n";
  if(_typed)
    _typed->displayTree(out, indent + 1);
}

ScopeSet *MuOptDeclChoose::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;

  if(_typed) {
    temp = _typed->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}


MuOptDeclProc::MuOptDeclProc(procdecl *n)
  : MuOptDecl(Proc, n ? n->name : NULL), _node(n),
    _params(n ? n->params : NULL), _decls(n ? n->decls : NULL),
    _body(n ? n->body : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclProc::MuOptDeclProc(procdecl*)\n";
#endif
}

MuOptDeclProc::~MuOptDeclProc() {
}

void MuOptDeclProc::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclProc::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Proc \"" << name() << "\"\n";
  if(_node && 0 /*+*+* need to verify that this is all valid */) {
    indentLine(out, indent + 1);
    out << "params\n";
    _params.displayTree(out, indent + 2);
    indentLine(out, indent + 1);
    out << "decls\n";
    _decls.displayTree(out, indent + 2);
    indentLine(out, indent + 1);
    out << "body\n";
    _body.displayTree(out, indent + 2);
  }
}

ScopeSet *MuOptDeclProc::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  // This is sort of a shotgun approach.  In theory nothing above this
  // point should ever have dependencies on things like the scope of
  // params.
  result = _params.deps(reqNum);

  temp = _decls.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}


MuOptDeclFunc::MuOptDeclFunc(funcdecl *n)
  : MuOptDecl(Proc, n ? n->name : NULL), _node(n),
    _params(n ? n->params : NULL), _decls(n ? n->decls : NULL),
    _body(n ? n->body : NULL), _returntype(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclFunc::MuOptDeclFunc(funcdecl*)\n";
#endif
  if(_node) {
    _returntype = MuOptDecl::newMuOptDecl(_node->returntype);
    assert(_returntype);
  }
}

MuOptDeclFunc::~MuOptDeclFunc() {
  //delete _returntype;
}

void MuOptDeclFunc::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclFunc::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Func \"" << name() << "\"\n";
  if(_node) {
    indentLine(out, indent + 1);
    out << "params\n";
    _params.displayTree(out, indent + 2);
    indentLine(out, indent + 1);
    out << "decls\n";
    _decls.displayTree(out, indent + 2);
    indentLine(out, indent + 1);
    out << "body\n";
    _body.displayTree(out, indent + 2);
    indentLine(out, indent + 1);
    out << "returntype\n";
    _returntype->displayTree(out, indent + 2);
  }
}

ScopeSet *MuOptDeclFunc::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _params.deps(reqNum);

  temp = _decls.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _returntype->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}


MuOptDeclError::MuOptDeclError(error_decl *n)
  : MuOptDecl(Error, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclError::MuOptDeclError(error_decl*)\n";
#endif
}

MuOptDeclError::~MuOptDeclError() {
}

void MuOptDeclError::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDeclError::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Error_decl \"" << name() << "\"\n";
}

ScopeSet *MuOptDeclError::deps(uint reqNum = 0) const {
  return new ScopeSet;
}
