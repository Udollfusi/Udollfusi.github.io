// mu_opt_decl.cc    -*- c++ -*-

#include "mu_opt_decl.h"
#include "mu_opt_param.h"
#include "mu_opt_typedecl.h"


map<typedecl*,MuOptTypeDecl*> MuOptTypeDecl::_existing;


MuOptTypeDecl::~MuOptTypeDecl() {
}

void MuOptTypeDecl::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDecl::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Type \"" << name() << "\"\n";
}

MuOptTypeDecl *MuOptTypeDecl::newMuOptTypeDecl(typedecl *td) {
  MuOptTypeDecl *result = NULL;
  if(td)
    if(_existing.find(td) == _existing.end()) {
      switch(td->gettypeclass()) {
      case typedecl::Enum:
        result = new MuOptTypeDeclEnum(dynamic_cast<enumtypedecl*>(td));
        break;
      case typedecl::Range:
        result=new MuOptTypeDeclRange(dynamic_cast<subrangetypedecl*>(td));
        break;
      case typedecl::Array:
        result = new MuOptTypeDeclArray(dynamic_cast<arraytypedecl*>(td));
        break;
      case typedecl::MultiSet:
        result = new MuOptTypeDeclMultiSet(dynamic_cast<multisettypedecl*>
                                           (td));
        break;
      case typedecl::MultiSetID:
        result = new
          MuOptTypeDeclMultiSetID(dynamic_cast<multisetidtypedecl*>(td));
        break;
      case typedecl::Record:
        result=new MuOptTypeDeclRecord(dynamic_cast<recordtypedecl*>(td));
        break;
      case typedecl::Scalarset:
        result = new
          MuOptTypeDeclScalarset(dynamic_cast<scalarsettypedecl*>(td));
        break;
      case typedecl::Union:
        result = new MuOptTypeDeclUnion(dynamic_cast<uniontypedecl*>(td));
        break;
      case typedecl::Error_type:
        result = new MuOptTypeDeclError(dynamic_cast<errortypedecl*>(td));
        break;
      default:
        assert(0);
        break;
      }
      _existing[td] = result;
    }else {
      result = _existing[td];
#ifdef MUOPT_DEBUG
      cerr << "reissuing existing typedecl\n";
#endif
    }
  return result;
}


MuOptTypeDeclEnum::MuOptTypeDeclEnum(enumtypedecl *n)
  : MuOptTypeDecl(Enum, n ? n->name : NULL), _node(n),
    _left(n ? n->getleft() : -1), _right(n ? n->getright() : -1),
    _idvalues(n ? n->getidvalues() : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclEnum::MuOptTypeDeclEnum(enumtypedecl*)\n";
#endif
}

MuOptTypeDeclEnum::~MuOptTypeDeclEnum() {
}

void MuOptTypeDeclEnum::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclEnum::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is Enum\n";
  indentLine(out, indent + 2);
  out << "left " << _left << ", right " << _right << "\n";
  indentLine(out, indent + 2);
  out << "idvalues\n";
  _idvalues.displayTree(out, indent + 3);
}

ScopeSet *MuOptTypeDeclEnum::deps(uint reqNum = 0) const {
  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  return _idvalues.deps(reqNum);
}


MuOptTypeDeclRange::MuOptTypeDeclRange(subrangetypedecl *n)
  : MuOptTypeDecl(Range, n ? n->name : NULL), _node(n),
    _left(n ? n->getleft() : -1), _right(n ? n->getright() : -1) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclRange::MuOptTypeDeclRange(subrangetypedecl*)\n";
#endif
}

MuOptTypeDeclRange::~MuOptTypeDeclRange() {
}

void MuOptTypeDeclRange::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclRange::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is Range\n";
  indentLine(out, indent + 2);
  out << "left " << _left << ", right " << _right << "\n";
}

ScopeSet *MuOptTypeDeclRange::deps(uint reqNum = 0) const {
  return new ScopeSet;
}


MuOptTypeDeclArray::MuOptTypeDeclArray(arraytypedecl *n)
  : MuOptTypeDecl(Array, n ? n->name : NULL), _node(n),
    _indexType(NULL), _elementType(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclArray::MuOptTypeDeclArray(arraytypedecl*)\n";
#endif
  if(n) {
    if(n->getindextype())
      _indexType = MuOptTypeDecl::newMuOptTypeDecl(n->getindextype());
    if(n->getelementtype())
      _elementType = MuOptTypeDecl::newMuOptTypeDecl(n->getelementtype());
  }
}

MuOptTypeDeclArray::~MuOptTypeDeclArray() {
  //delete _indexType;
  //delete _elementType;
}

void MuOptTypeDeclArray::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclArray::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is Array\n";
  if(_indexType) {
    indentLine(out, indent + 1);
    out << "[index type]\n";
    _indexType->displayTree(out, indent + 2);
  }
  if(_elementType) {
    indentLine(out, indent + 1);
    out << "[element type]\n";
    _elementType->displayTree(out, indent + 2);
  }
}

ScopeSet *MuOptTypeDeclArray::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  if(_indexType)
    result = _indexType->deps(reqNum);
  else
    result = new ScopeSet;

  if(_elementType) {
    temp = _elementType->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}


MuOptTypeDeclMultiSet::MuOptTypeDeclMultiSet(multisettypedecl *n)
  : MuOptTypeDecl(MultiSet, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr <<
    "MuOptTypeDeclMultiSet::MuOptTypeDeclMultiSet(multisettypedecl*)\n";
#endif
  //assert(0);
}

MuOptTypeDeclMultiSet::~MuOptTypeDeclMultiSet() {
}

void MuOptTypeDeclMultiSet::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclMultiSet::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is MultiSet\n";
}

ScopeSet *MuOptTypeDeclMultiSet::deps(uint reqNum = 0) const {
  //assert(0);
  return new ScopeSet;
  /*
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
  */
}


MuOptTypeDeclMultiSetID::MuOptTypeDeclMultiSetID(multisetidtypedecl *n)
  : MuOptTypeDecl(MultiSetID, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclMultiSetID::"
    "MuOptTypeDeclMultiSetID(multisetidtypedecl*)\n";
#endif
  assert(0);
}

MuOptTypeDeclMultiSetID::~MuOptTypeDeclMultiSetID() {
}

void MuOptTypeDeclMultiSetID::displayTree(ostream& out, uint indent) const{
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclSetID::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is MultiSetID\n";
}

ScopeSet *MuOptTypeDeclMultiSetID::deps(uint reqNum = 0) const {
  assert(0);
  return NULL;
  /*
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
  */
}


MuOptTypeDeclRecord::MuOptTypeDeclRecord(recordtypedecl *n)
  : MuOptTypeDecl(Record, n ? n->name : NULL), _node(n),
    _fields(n ? n->getfields() : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclRecord::MuOptTypeDeclRecord(recordtypedecl*)\n";
#endif
}

MuOptTypeDeclRecord::~MuOptTypeDeclRecord() {
}

void MuOptTypeDeclRecord::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclRecord::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is Record\n";
  indentLine(out, indent + 2);
  out << "fields\n";
  _fields.displayTree(out, indent + 3);
}

ScopeSet *MuOptTypeDeclRecord::deps(uint reqNum = 0) const {
  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  return _fields.deps(reqNum);
}


MuOptTypeDeclScalarset::MuOptTypeDeclScalarset(scalarsettypedecl *n)
  : MuOptTypeDecl(Scalarset, n ? n->name : NULL), _node(n),
    _left(n ? n->getleft() : -1), _right(n ? n->getright() : -1),
    _idvalues(n ? n->getidvalues() : NULL) {
#ifdef MUOPT_DEBUG
  cerr <<
    "MuOptTypeDeclScalarset::MuOptTypeDeclScalarset(scalarsettypedecl*)\n";
#endif
  //assert(!n->useless);
}

MuOptTypeDeclScalarset::~MuOptTypeDeclScalarset() {
}

void MuOptTypeDeclScalarset::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclScalarset::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is Scalarset\n";
  indentLine(out, indent + 2);
  out << "further dependencies ignored\n";
}

ScopeSet *MuOptTypeDeclScalarset::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _idvalues.deps(reqNum);

  /*
  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;
  */

  return result;
}


MuOptTypeDeclUnion::MuOptTypeDeclUnion(uniontypedecl *n)
  : MuOptTypeDecl(Union, n ? n->name : NULL), _node(n),
    _unionmembers(n ? n->getunionmembers() : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclUnion::MuOptTypeDeclUnion(uniontypedecl*)\n";
#endif
  
}

MuOptTypeDeclUnion::~MuOptTypeDeclUnion() {
}

void MuOptTypeDeclUnion::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclUnion::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "typeclass is Union\n";
  indentLine(out, indent + 2);
  out << "further dependencies ignored\n";
}

ScopeSet *MuOptTypeDeclUnion::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _unionmembers.deps(reqNum);

  /*
  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;
  */

  return result;
}


MuOptTypeDeclError::MuOptTypeDeclError(errortypedecl *n)
  : MuOptTypeDecl(Error, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclError::MuOptTypeDeclError(errortypedecl*)\n";
#endif
}

MuOptTypeDeclError::~MuOptTypeDeclError() {
}

void MuOptTypeDeclError::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptTypeDeclError::displayTree(int) const\n";
#endif
  MuOptTypeDecl::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "Error_type\n";
}

ScopeSet *MuOptTypeDeclError::deps(uint reqNum = 0) const {
  return new ScopeSet;
}
