// mu_opt_param.cc    -*- c++ -*-

#include "mu_opt_param.h"


map<param*,MuOptParam*> MuOptParam::_existing;


MuOptParam::MuOptParam(Type t, const char *name)
  : MuOptDecl(Param, name), _type(t) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParam::MuOptParam(Type, const char*)\n";
#endif
}

MuOptParam::~MuOptParam() {
}

void MuOptParam::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParam::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "decl_class is Param \"" << name() << "\"\n";
}

MuOptParam *MuOptParam::newMuOptParam(param *p) {
  MuOptParam *result = NULL;
  if(p)
    if(_existing.find(p) == _existing.end()) {
      switch(p->getparamclass()) {
      case param::Value:
        result = new MuOptParamValue(dynamic_cast<valparam*>(p));
        break;
      case param::Var:
        result = new MuOptParamVar(dynamic_cast<varparam*>(p));
        break;
      case param::Const:
        result = new MuOptParamConst(dynamic_cast<constparam*>(p));
        break;
      case param::Name:
        assert(0);  // these don't actually exist in Murphi 3.1!?!
        //result = new MuOptParamName(dynamic_cast<nameparam*>(p));
        break;
      case param::Error_param:
        result = new MuOptParamError(p);
        break;
      default:
        assert(0);
        break;
      }
      _existing[p] = result;
    } else {
      result = _existing[p];
#ifdef MUOPT_DEBUG
      cerr << "reissuing existing param\n";
#endif
    }
  return result;
}


MuOptParamValue::MuOptParamValue(valparam *n)
  : MuOptParam(Value, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamValue::MuOptParamValue(valparam*)\n";
#endif
}

MuOptParamValue::~MuOptParamValue() {
}

void MuOptParamValue::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamValue::displayTree(int) const\n";
#endif
  MuOptParam::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "param_class is Value\n";
}

ScopeSet *MuOptParamValue::deps(uint reqNum = 0) const {
  return new ScopeSet;
}


MuOptParamVar::MuOptParamVar(varparam *n)
  : MuOptParam(Var, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamVar::MuOptParamVar(varparam*)\n";
#endif
}

MuOptParamVar::~MuOptParamVar() {
}

void MuOptParamVar::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamVar::displayTree(int) const\n";
#endif
  MuOptParam::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "param_class is Var\n";
}

ScopeSet *MuOptParamVar::deps(uint reqNum = 0) const {
  return new ScopeSet;
}


MuOptParamConst::MuOptParamConst(constparam *n)
  : MuOptParam(Const, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamConst::MuOptParamConst(constparam*)\n";
#endif
}

MuOptParamConst::~MuOptParamConst() {
}

void MuOptParamConst::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamConst::displayTree(int) const\n";
#endif
  MuOptParam::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "param_class is Const\n";
}

ScopeSet *MuOptParamConst::deps(uint reqNum = 0) const {
  return new ScopeSet;
}


/*
MuOptParamName::MuOptParamName(nameparam *n)
  : MuOptParam(Name, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamName::MuOptParamName(nameparam*)\n";
#endif
}

MuOptParamName::~MuOptParamName() {
}

void MuOptParamName::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamName::displayTree(int) const\n";
#endif
  MuOptParam::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "param_class is Name\n";
}

ScopeSet *MuOptParamName::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}
*/


MuOptParamError::MuOptParamError(param *n)
  : MuOptParam(Error, n ? n->name : NULL), _node(n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamError::MuOptParamError(param*)\n";
#endif
}

MuOptParamError::~MuOptParamError() {
}

void MuOptParamError::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptParamError::displayTree(int) const\n";
#endif
  MuOptParam::displayTree(out, indent);
  indentLine(out, indent + 1);
  out << "param_class is Error\n";
}

ScopeSet *MuOptParamError::deps(uint reqNum = 0) const {
  return new ScopeSet;
}
