// mu_opt_stmt.cc    -*- c++ -*-

#include "mu_opt_stmt.h"
#include <typeinfo>


map<stmt*,MuOptStmt*> MuOptStmt::_existing;


MuOptStmt::~MuOptStmt() {
}

MuOptStmt *MuOptStmt::newMuOptStmt(stmt *s) {
  MuOptStmt *result = NULL;
  if(s)
    if(_existing.find(s) == _existing.end()) {
      // no getclass() here, so get to use RTTI (woohoo!)
      if(typeid(*s) == typeid(assignment))
        result = new MuOptStmtAssignment(dynamic_cast<assignment*>(s));
      else if(typeid(*s) == typeid(whilestmt))
        result = new MuOptStmtWhile(dynamic_cast<whilestmt*>(s));
      else if(typeid(*s) == typeid(ifstmt))
        result = new MuOptStmtIf(dynamic_cast<ifstmt*>(s));
      else if(typeid(*s) == typeid(caselist))
        result = new MuOptStmtCase(dynamic_cast<caselist*>(s));
      else if(typeid(*s) == typeid(switchstmt))
        result = new MuOptStmtSwitch(dynamic_cast<switchstmt*>(s));
      else if(typeid(*s) == typeid(forstmt))
        result = new MuOptStmtFor(dynamic_cast<forstmt*>(s));
      else if(typeid(*s) == typeid(proccall))
        result = new MuOptStmtProc(dynamic_cast<proccall*>(s));
      else if(typeid(*s) == typeid(clearstmt))
        result = new MuOptStmtClear(dynamic_cast<clearstmt*>(s));
      else if(typeid(*s) == typeid(errorstmt))
        result = new MuOptStmtError(dynamic_cast<errorstmt*>(s));
      else if(typeid(*s) == typeid(assertstmt))
        result = new MuOptStmtAssert(dynamic_cast<assertstmt*>(s));
      else if(typeid(*s) == typeid(putstmt))
        result = new MuOptStmtPut(dynamic_cast<putstmt*>(s));
      else if(typeid(*s) == typeid(alias))
        result = new MuOptStmtAlias(dynamic_cast<alias*>(s));
      else if(typeid(*s) == typeid(aliasstmt))
        result = new MuOptStmtAliasstmt(dynamic_cast<aliasstmt*>(s));
      else if(typeid(*s) == typeid(returnstmt))
        result = new MuOptStmtReturn(dynamic_cast<returnstmt*>(s));
      else if(typeid(*s) == typeid(undefinestmt))  // not on "the list"
        result = new MuOptStmtUndefine(dynamic_cast<undefinestmt*>(s));
      else if(typeid(*s) == typeid(multisetaddstmt))  // not on "the list"
        result=new MuOptStmtMultisetAdd(dynamic_cast<multisetaddstmt*>(s));
      else if(typeid(*s) == typeid(multisetremovestmt)) //not on "the list"
        result = new
          MuOptStmtMultisetRemove(dynamic_cast<multisetremovestmt*>(s));
      else if(s == nullstmt)  // have to read carefully to find this one
        result = new MuOptStmtNull();
      else
        assert(0);
      _existing[s] = result;
    } else {
      result = _existing[s];
#ifdef MUOPT_DEBUG
      cerr << "reissuing existing stmt\n";
#endif
    }
  return result;
}

MuOptStmtList::MuOptStmtList(stmt *s) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtList::MuOptStmtList(stmt*)\n";
#endif
  while(s) {
    MuOptStmt *mos = MuOptStmt::newMuOptStmt(s);
    if(mos)
      _list.push_back(mos);
    s = s->next;
  }
}

MuOptStmtList::~MuOptStmtList() {
  while(! _list.empty()) {
    //delete _list.front();
    _list.pop_front();
  }
}

void MuOptStmtList::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtList::displayTree(int) const\n";
#endif
  //indentLine(indent - 1);
  //out << "[stmtlist]\n";
  for(list<MuOptStmt*>::const_iterator i=_list.begin();i!=_list.end();i++)
    (*i)->displayTree(out, indent);
}

ScopeSet *MuOptStmtList::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;
  for(list<MuOptStmt*>::const_iterator i=_list.begin();i!=_list.end();i++){
    temp = (*i)->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}


MuOptStmtAssignment::MuOptStmtAssignment(assignment *a) :
  MuOptStmt(Assignment), _node(a), _src(a ? a->src : NULL), _target(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAssignment::MuOptStmtAssignment(assignment*)\n";
#endif
  assert(a);
  _target = MuOptDesignator::newMuOptDesignator(a->target);
  assert(_target);
}

MuOptStmtAssignment::~MuOptStmtAssignment() {
}

void MuOptStmtAssignment::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAssignment::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "assignment\n";
  indentLine(out, indent + 1);
  out << "target\n";
  _target->displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "src\n";
  _src.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtAssignment::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _target->deps(reqNum);

  temp = _src.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtWhile::MuOptStmtWhile(whilestmt *w) :
  MuOptStmt(While), _node(w), _test(w->test), _body(_node->body) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtWhile::MuOptStmtWhile(whilestmt*)\n";
#endif
}

MuOptStmtWhile::~MuOptStmtWhile() {
}

void MuOptStmtWhile::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtWhile::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "whilestmt\n";
  indentLine(out, indent + 1);
  out << "test\n";
  _test.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "body\n";
  _body.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtWhile::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _test.deps(reqNum);

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtIf::MuOptStmtIf(ifstmt *i) :
  MuOptStmt(If), _node(i), _test(i->test), _body(i->body),
  _else(i->elsecode) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtIf::MuOptStmtIf(ifstmt*)\n";
#endif
}

MuOptStmtIf::~MuOptStmtIf() {
}

void MuOptStmtIf::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtIf::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "ifstmt\n";
  indentLine(out, indent + 1);
  out << "test\n";
  _test.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "body\n";
  _body.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "elsecode\n";
  _else.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtIf::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _test.deps(reqNum);

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _else.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtCase::MuOptStmtCase(caselist *c) :
  MuOptStmt(Case), _node(c), _values(c->values), _body(c->body) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtCase::MuOptStmtCase(caselist*)\n";
#endif
}

MuOptStmtCase::~MuOptStmtCase() {
}

void MuOptStmtCase::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtCase::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "case\n";
  indentLine(out, indent + 1);
  out << "values\n";
  _values.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "body\n";
  _body.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtCase::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _values.deps(reqNum);

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtCaseList::MuOptStmtCaseList(caselist *c) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtCaseList::MuOptStmtCaseList(caselist*)\n";
#endif
  while(c) {
    MuOptStmtCase *mosc = new MuOptStmtCase(c);
    if(mosc)
      _list.push_back(mosc);
    c = c->next;
  }
}

MuOptStmtCaseList::~MuOptStmtCaseList() {
  while(! _list.empty()) {
    //delete _list.front();
    _list.pop_front();
  }
}

void MuOptStmtCaseList::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtCaseList::displayTree(int) const\n";
#endif
  for(list<MuOptStmtCase*>::const_iterator i = _list.begin();
      i != _list.end(); i++)
    (*i)->displayTree(out, indent);
}

ScopeSet *MuOptStmtCaseList::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;
  for(list<MuOptStmtCase*>::const_iterator i = _list.begin();
      i != _list.end(); i++) {
    temp = (*i)->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}

MuOptStmtSwitch::MuOptStmtSwitch(switchstmt *s) :
  MuOptStmt(Switch), _node(s), _expr(s->switchexpr), _cases(s->cases),
  _default(s->elsecode) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtSwitch::MuOptStmtSwitch(switchstmt*)\n";
#endif
}

MuOptStmtSwitch::~MuOptStmtSwitch() {
}

void MuOptStmtSwitch::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtSwitch::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "switchstmt\n";
  indentLine(out, indent + 1);
  out << "switchexpr\n";
  _expr.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "cases\n";
  _cases.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "elsecode\n";
  _default.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtSwitch::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _expr.deps(reqNum);

  temp = _cases.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _default.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtFor::MuOptStmtFor(forstmt *f) :
  MuOptStmt(For), _node(f), _index(f->index), _body(f->body) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtFor::MuOptStmtFor(forstmt*)\n";
#endif
}

MuOptStmtFor::~MuOptStmtFor() {
}

void MuOptStmtFor::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtFor::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "forstmt\n";
  indentLine(out, indent + 1);
  out << "index\n";
  _index.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "body\n";
  _body.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtFor::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _index.deps(reqNum);

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtProc::MuOptStmtProc(proccall *p) :
  MuOptStmt(Proc), _node(p), _procedure(p->procedure),
  _actuals(p->actuals) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtProc::MuOptStmtProc(proccall*)\n";
#endif
}

MuOptStmtProc::~MuOptStmtProc() {
}

void MuOptStmtProc::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtProc::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "proccall\n";
  indentLine(out, indent + 1);
  out << "procedure\n";
  _procedure.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "actuals\n";
  _actuals.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtProc::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _procedure.deps(reqNum);

  temp = _actuals.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtClear::MuOptStmtClear(clearstmt *c) :
  MuOptStmt(Clear), _node(c), _target(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtClear::MuOptStmtClear(clearstmt*)\n";
#endif
  assert(c);
  _target = MuOptDesignator::newMuOptDesignator(c->target);
  assert(_target);
}

MuOptStmtClear::~MuOptStmtClear() {
  //delete _target;
}

void MuOptStmtClear::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtClear::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "clearstmt\n";
  indentLine(out, indent + 1);
  out << "target\n";
  _target->displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtClear::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _target->deps(reqNum);

  /*
  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;
  */

  return result;
}

MuOptStmtError::MuOptStmtError(errorstmt *c) :
  MuOptStmt(Error), _node(c), _string(c->string) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtError::MuOptStmtError(errorstmt*)\n";
#endif
}

MuOptStmtError::MuOptStmtError(errorstmt *c, bool isassert) :
  MuOptStmt(isassert ? Assert : Error), _node(c), _string(c->string) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtError::MuOptStmtError(errorstmt*, bool)\n";
#endif
}

MuOptStmtError::~MuOptStmtError() {
}

void MuOptStmtError::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtError::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "errorstmt \"" << _string << "\"\n";
}

ScopeSet *MuOptStmtError::deps(uint reqNum = 0) const {
  //assert(0);
  return new ScopeSet;
}

MuOptStmtAssert::MuOptStmtAssert(assertstmt *c) :
  MuOptStmtError(c, true), _node(c), _test(c->test){
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAssert::MuOptStmtAssert(assertstmt*)\n";
#endif
}

MuOptStmtAssert::~MuOptStmtAssert() {
}

void MuOptStmtAssert::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAssert::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "assertstmt\n";
  indentLine(out, indent + 1);
  out << "test\n";
  _test.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "string\n";
  indentLine(out, indent + 2);
  out << errstring() << "\n";
}

ScopeSet *MuOptStmtAssert::deps(uint reqNum = 0) const {
  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  return _test.deps(reqNum);
}

MuOptStmtPut::MuOptStmtPut(putstmt *c) :
  MuOptStmt(Put), _node(c) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtPut::MuOptStmtPut(putstmt*)\n";
#endif
    assert(0);
}

MuOptStmtPut::~MuOptStmtPut() {
}

void MuOptStmtPut::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtPut::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "putstmt\n";
}

ScopeSet *MuOptStmtPut::deps(uint reqNum = 0) const {
  assert(0);
  return NULL;
  /*
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
  */
}

MuOptStmtAlias::MuOptStmtAlias(alias *c) :
  MuOptStmt(Alias), _node(c) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAlias::MuOptStmtAlias(alias*)\n";
#endif
    assert(0);
}

MuOptStmtAlias::~MuOptStmtAlias() {
}

void MuOptStmtAlias::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAlias::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "alias\n";
}

ScopeSet *MuOptStmtAlias::deps(uint reqNum = 0) const {
  assert(0);
  return NULL;
  /*
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
  */
}

MuOptStmtAliasstmt::MuOptStmtAliasstmt(aliasstmt *a) :
  MuOptStmt(Aliasstmt), _node(a), _aliases(a->aliases), _body(a->body) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtAliasstmt::MuOptStmtAliasstmt(aliasstmt*)\n";
#endif
}

MuOptStmtAliasstmt::~MuOptStmtAliasstmt() {
}

void MuOptStmtAliasstmt::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptAliasstmt::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "aliasstmt\n";
  indentLine(out, indent + 1);
  out << "aliases\n";
  _aliases.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "body\n";
  _body.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtAliasstmt::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _aliases.deps(reqNum);

  temp = _body.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtReturn::MuOptStmtReturn(returnstmt *r) :
  MuOptStmt(Return), _node(r), _retexpr(r->retexpr) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtReturn::MuOptStmtReturn(returnstmt*)\n";
#endif
}

MuOptStmtReturn::~MuOptStmtReturn() {
}

void MuOptStmtReturn::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtReturn::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "returnstmt\n";
  indentLine(out, indent + 1);
  out << "retexpr\n";
  _retexpr.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtReturn::deps(uint reqNum = 0) const {
  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  return _retexpr.deps(reqNum);
}

MuOptStmtUndefine::MuOptStmtUndefine(undefinestmt *u) :
  MuOptStmt(Undefine), _node(u), _target(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtUndefine::MuOptStmtUndefine(undefinestmt*)\n";
#endif
  _target = MuOptDesignator::newMuOptDesignator(u ? u->target : NULL);
  assert(_target);
}

MuOptStmtUndefine::~MuOptStmtUndefine() {
}

void MuOptStmtUndefine::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtUndefine::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "undefinestmt\n";
  _target->displayTree(out, indent + 1);
}

ScopeSet *MuOptStmtUndefine::deps(uint reqNum = 0) const {
  ScopeSet *result;//, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _target->deps(reqNum);

  /*
  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;
  */

  return result;
}

MuOptStmtMultisetAdd::MuOptStmtMultisetAdd(multisetaddstmt *u) :
  MuOptStmt(MultisetAdd), _node(u), _element(NULL), _target(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtMultisetAdd::MuOptStmtMultisetAdd(multisetaddstmt*)\n";
#endif
  _element = MuOptDesignator::newMuOptDesignator(u ? u->element : NULL);
  assert(_element);
  _target = MuOptDesignator::newMuOptDesignator(u ? u->target : NULL);
  assert(_target);
}

MuOptStmtMultisetAdd::~MuOptStmtMultisetAdd() {
}

void MuOptStmtMultisetAdd::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptMultisetAdd::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "multisetaddstmt\n";
  indentLine(out, indent + 1);
  out << "element\n";
  _element->displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "target\n";
  _target->displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtMultisetAdd::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _element->deps(reqNum);

  temp = _target->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtMultisetRemove::MuOptStmtMultisetRemove(multisetremovestmt *u) :
  MuOptStmt(MultisetRemove), _node(u), _index(u ? u->index : NULL),
  _target(NULL), _criterion(u ? u->criterion : NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtMultisetRemove::"
    "MuOptStmtMultisetRemove(multisetremovestmt*)\n";
#endif
  _target = MuOptDesignator::newMuOptDesignator(u ? u->target : NULL);
  assert(_target);
}

MuOptStmtMultisetRemove::~MuOptStmtMultisetRemove() {
  //delete _target;
}

void MuOptStmtMultisetRemove::displayTree(ostream& out, uint indent) const{
#ifdef MUOPT_DEBUG
  cerr << "MuOptMultisetRemove::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "multisetremovestmt\n";
  indentLine(out, indent + 1);
  out << "index\n";
  _index.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "target\n";
  _target->displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "criterion\n";
  _criterion.displayTree(out, indent + 2);
}

ScopeSet *MuOptStmtMultisetRemove::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _index.deps(reqNum);

  temp = _target->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _criterion.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

MuOptStmtNull::MuOptStmtNull() : MuOptStmt(Null) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtNull::MuOptStmtNull()\n";
#endif
}

MuOptStmtNull::~MuOptStmtNull() {
}

void MuOptStmtNull::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptStmtNull::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "null statement\n";
}

ScopeSet *MuOptStmtNull::deps(uint reqNum = 0) const {
  return new ScopeSet;
}
