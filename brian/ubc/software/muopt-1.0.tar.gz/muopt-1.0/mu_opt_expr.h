// mu_opt_expr.h    -*- c++ -*-

#ifndef MU_OPT_EXPR_H
#define MU_OPT_EXPR_H

#include "mu_opt_base.h"
#include "mu_opt_ste.h"

class MuOptExpr : public MuOptObject {
public:
  MuOptExpr(expr *e);
  virtual ~MuOptExpr();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  expr *_node; // do not own
  MuOptSTEChain *_used;
};

class MuOptDesignator {
public:
  MuOptDesignator() { }
  virtual ~MuOptDesignator();

  virtual void displayTree(ostream& out, uint indent) const = 0;
  virtual ScopeSet *deps(uint reqNum = 0) const = 0;

  virtual bool isList() const = 0;

  static MuOptDesignator *newMuOptDesignator(designator *);
};

class MuOptDesignatorInstance : public MuOptExpr, public MuOptDesignator {
public:
  MuOptDesignatorInstance(designator *d);
  virtual ~MuOptDesignatorInstance();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

  bool isList() const;

private:
  MuOptSTE _origin;
  MuOptExpr _arrayref;
  MuOptSTE _fieldref;
};

class MuOptExprList : public MuOptObject {
public:
  MuOptExprList(exprlist *e);
  virtual ~MuOptExprList();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  list<MuOptExpr*> _list;
};

class MuOptDesignatorList : public MuOptObject, public MuOptDesignator {
public:
  MuOptDesignatorList(designator *d);
  virtual ~MuOptDesignatorList();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

  bool isList() const;

private:
  list<MuOptDesignatorInstance*> _list;
};

#endif /* MU_OPT_EXPR_H */
