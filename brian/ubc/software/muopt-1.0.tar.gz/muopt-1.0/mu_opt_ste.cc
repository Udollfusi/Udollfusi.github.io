// mu_opt_ste.cc    -*- c++ -*-

#include "mu_opt_ste.h"
#include "mu_opt_decl.h"


MuOptSTE::MuOptSTE(ste *s)
  : MuOptObject(s ? (s->getname() ? s->getname()->getname() : NULL) :NULL),
    _node(s), _scope(s ? s->getscope() : -1),
    _lextype(s ? (s->getname() ? s->getname()->getlextype() : -2) : -1),
    _value(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptSTE::MuOptSTE(ste*)\n";
#endif
  //assert(_lextype != -1);
  assert(_lextype != -2);
  if(_node) {
    _value = MuOptDecl::newMuOptDecl(_node->getvalue());
    assert(_value);
  }
}

MuOptSTE::~MuOptSTE() {
  //delete _value;
}

void MuOptSTE::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptSTE::displayTree(int) const\n";
#endif
  if(_node) {
    indentLine(out, indent);
    out << "[ste]";
    if(_node->getname())
      out << " " << _scope << "::" << name() << "(" << _lextype << ")";
    out << "\n";
    if(_value) {
      indentLine(out, indent + 1);
      out << "value\n";
      _value->displayTree(out, indent + 2);
    }
  }
}

ScopeSet *MuOptSTE::deps(uint reqNum = 0) const {
  ScopeSet *result;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  if(_value)
    result = _value->deps(reqNum);
  else
    result = new ScopeSet;

  result->insert(_scope);

  return result;
}

MuOptSTEChain::MuOptSTEChain(ste *start, ste *stop) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptSTEChain::MuOptSTEChain(ste*, ste*)\n";
#endif
  for(ste *i = start; i && i != stop; i = i->next) {
    MuOptSTE *s = new MuOptSTE(i);
    assert(s);
    if(s)
      _chain.push_back(s);
  }
}

MuOptSTEChain::MuOptSTEChain(stelist *start, stelist *stop) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptSTEChain::MuOptSTEChain(stelist*, stelist*)\n";
#endif
  for(stelist *i = start; i && i != stop; i = i->next)
    for(ste *j = i->s; j; j = j->next) {
      MuOptSTE *s = new MuOptSTE(j);
      assert(s);
      if(s)
        _chain.push_back(s);
    }
}

MuOptSTEChain::MuOptSTEChain(stecoll *s) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptSTEChain::MuOptSTEChain(stecoll*)\n";
#endif
  // The way this one works doesn't make a ton of sense to me, but then
  // why have redundant data structures?  (Ans: because Murphi is only
  // weakly OO, and not at all OO when it comes to STEs.)
  if(s)
    for(stelist *i = s->first; i; i = i->next) {
      MuOptSTE *n = new MuOptSTE(i->s);
      assert(s);
      if(n)
        _chain.push_back(n);
    }
}

MuOptSTEChain::~MuOptSTEChain() {
  while(! _chain.empty()) {
    //delete _chain.front();
    _chain.pop_front();
  }
}

void MuOptSTEChain::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptSTEChain::displayTree(int) const\n";
#endif
  for(list<MuOptSTE*>::const_iterator i = _chain.begin();
      i != _chain.end(); i++) {
    (*i)->displayTree(out, indent);
  }
}

ScopeSet *MuOptSTEChain::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;
  for(list<MuOptSTE*>::const_iterator i = _chain.begin();
      i != _chain.end(); i++) {
    temp = (*i)->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}


ScopeSet *MuOptSTEChain::scopes() const {
  ScopeSet *result = new ScopeSet;

  for(list<MuOptSTE*>::const_iterator i = _chain.begin();
      i != _chain.end(); i++)
    result->insert((*i)->scope());

  return result;
}
