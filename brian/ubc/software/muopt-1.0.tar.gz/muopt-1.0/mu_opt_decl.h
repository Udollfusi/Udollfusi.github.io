// mu_opt_decl.h    -*- c++ -*-

#ifndef MU_OPT_DECL_H
#define MU_OPT_DECL_H

#include "mu_opt_base.h"
#include "mu_opt_ste.h"
#include "mu_opt_stmt.h"
#include <map>


class MuOptTypeDecl;

class MuOptDecl : public MuOptObject {
public:
  enum Type { TypeDecl, Const, Var, Alias, Quant, Choose, Param, Proc,
              Func, Error, unknown };

protected:
  MuOptDecl(Type t, const char *name) : MuOptObject(name), _type(t) { }
public:
  virtual ~MuOptDecl();

  Type type() const { return _type; }

  static MuOptDecl *newMuOptDecl(decl *);

private:
  Type _type;
  static map<decl*,MuOptDecl*> _existing;
};

class MuOptDeclConst : public MuOptDecl {
public:
  MuOptDeclConst(constdecl *n);
  virtual ~MuOptDeclConst();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  constdecl *_node; // do not own
  MuOptTypeDecl *_typed;
};

class MuOptDeclVar : public MuOptDecl {
public:
  MuOptDeclVar(vardecl *n);
  virtual ~MuOptDeclVar();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  vardecl *_node; // do not own
  MuOptTypeDecl *_typed;
};

class MuOptDeclAlias : public MuOptDecl {
public:
  MuOptDeclAlias(aliasdecl *n);
  virtual ~MuOptDeclAlias();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  aliasdecl *_node; // do not own
  MuOptExpr _ref;
};

class MuOptDeclQuant : public MuOptDecl {
public:
  MuOptDeclQuant(quantdecl *n);
  virtual ~MuOptDeclQuant();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  quantdecl *_node; // do not own
  MuOptTypeDecl *_typed;
  MuOptExpr _left;
  MuOptExpr _right;
};

class MuOptDeclChoose : public MuOptDecl {
public:
  MuOptDeclChoose(choosedecl *n);
  virtual ~MuOptDeclChoose();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  choosedecl *_node; // do not own
  MuOptTypeDecl *_typed;
};

class MuOptDeclProc : public MuOptDecl {
public:
  MuOptDeclProc(procdecl *n);
  virtual ~MuOptDeclProc();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  procdecl *_node; // do not own
  MuOptSTEChain _params;
  MuOptSTEChain _decls;
  MuOptStmtList _body;
};

class MuOptDeclFunc : public MuOptDecl {
public:
  MuOptDeclFunc(funcdecl *n);
  virtual ~MuOptDeclFunc();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  funcdecl *_node; // do not own
  MuOptSTEChain _params;
  MuOptSTEChain _decls;
  MuOptStmtList _body;
  MuOptDecl *_returntype;
};

class MuOptDeclError : public MuOptDecl {
public:
  MuOptDeclError(error_decl *n);
  virtual ~MuOptDeclError();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  error_decl *_node; // do not own
};

#endif /* MU_OPT_DECL_H */
