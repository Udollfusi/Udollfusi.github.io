// mu_opt_rule.cc    -*- c++ -*-

#include "mu_opt_rule.h"
#include <typeinfo>

MuOptRuleBase::~MuOptRuleBase() {
}

MuOptRule::~MuOptRule() {
}

bool MuOptRule::isList() const {
  return false;
}

MuOptRule *MuOptRule::newMuOptRule(rule *r) {
  MuOptRule *result = NULL;
  if(r)
    switch(r->getclass()) {
    case rule::Simple:
      result = new MuOptRuleSimple(dynamic_cast<simplerule*>(r));
      break;
    case rule::Startstate:
      result = new MuOptRuleStartstate(dynamic_cast<startstate*>(r));
      break;
    case rule::Invar:
      result = new MuOptRuleInvar(dynamic_cast<invariant*>(r));
      break;
    case rule::Quant:
      result = new MuOptRuleQuant(dynamic_cast<quantrule*>(r));
      break;
    case rule::Choose:
      result = new MuOptRuleChoose(dynamic_cast<chooserule*>(r));
      break;
    case rule::Alias:
      result = new MuOptRuleAlias(dynamic_cast<aliasrule*>(r));
      break;
    case rule::Fair:
      result = new MuOptRuleFair(dynamic_cast<fairness*>(r));
      break;
    case rule::Live:
      result = new MuOptRuleLive(dynamic_cast<liveness*>(r));
      break;
    default:
      assert(0);
    }
  return result;
}

MuOptRule *MuOptRule::newMuOptRule(MuOptRule *r) {
  MuOptRule *result = NULL;
  if(r)
    if(typeid(*r) == typeid(MuOptRuleSimple))
      result = new MuOptRuleSimple(*dynamic_cast<MuOptRuleSimple*>(r));
    else if(typeid(*r) == typeid(MuOptRuleStartstate))
      result = new MuOptRuleStartstate(*dynamic_cast<MuOptRuleStartstate*>
                                       (r));
    else if(typeid(*r) == typeid(MuOptRuleInvar))
      result = new MuOptRuleInvar(*dynamic_cast<MuOptRuleInvar*>(r));
    else if(typeid(*r) == typeid(MuOptRuleQuant))
      result = new MuOptRuleQuant(*dynamic_cast<MuOptRuleQuant*>(r));
    else if(typeid(*r) == typeid(MuOptRuleChoose))
      result = new MuOptRuleChoose(*dynamic_cast<MuOptRuleChoose*>(r));
    else if(typeid(*r) == typeid(MuOptRuleAlias))
      result = new MuOptRuleAlias(*dynamic_cast<MuOptRuleAlias*>(r));
    else if(typeid(*r) == typeid(MuOptRuleFair))
      result = new MuOptRuleFair(*dynamic_cast<MuOptRuleFair*>(r));
    else if(typeid(*r) == typeid(MuOptRuleLive))
      result = new MuOptRuleLive(*dynamic_cast<MuOptRuleLive*>(r));
    else
      assert(0);
  return result;
}

MuOptRuleSimple::MuOptRuleSimple(simplerule *n)
  : MuOptRule(Simple, n ? n->name : NULL, n),
    _enclosures(n ? n->enclosures : NULL),
    _condition(n ? n->condition : NULL),
    _locals(n ? n->locals : NULL), _body(n ? n->body : NULL),
    _unfair(n ? n->unfair : false) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleSimple::MuOptRuleSimple(simplerule*)\n";
#endif
}

MuOptRuleSimple::MuOptRuleSimple(simplerule*n, Type _type)
  : MuOptRule(_type, n ? n->name : NULL, n),
    _enclosures(n ? n->enclosures : NULL),
    _condition(n && _type!=Startstate ? n->condition : NULL),
    _locals(n && _type!=Invar ? n->locals : NULL),
    _body(n && _type!=Invar ? n->body : NULL),
    _unfair(n ? n->unfair : false) {
}

MuOptRuleSimple::~MuOptRuleSimple() {
}

const char *MuOptRuleSimple::typeName() const {
  return "Simple";
}

void MuOptRuleSimple::rebuildRuleInfo(const ScopeSet *encl) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRule" << typeName()
       << "::rebuildRuleInfo(const ScopeSet*)\n";
#endif

  simplerule *n = dynamic_cast<simplerule*>(node());
  assert(n); 

  // update simplerule::SimpleRuleList
  n->NextSimpleRule = simplerule::SimpleRuleList;
  simplerule::SimpleRuleList = n;

  // update enclosures of this simplerule
  list<MuOptSTE*>& chain = _enclosures.chain();  // HACK:  unziiiip...
  if(encl) {
    // This is my second attempt (see CVS rev 1.10 for previous
    // version, commented out).  This is a bit ugly, but it should do.
    ste *last = NULL;
    ste *cur = n->enclosures;
    while(cur) {
      // HACK: global scope is hardcoded to 1
      // HACK++: don't throw out scope 0 either
      if(cur->scope > 1 && encl->find(cur->scope) == encl->end()) {
        cout << "cleanup:      rule \"" << name()
             << "\" removing unused enclosing scope "
             << cur->scope
             << " from simple rule deps\n";
        cur = cur->next;
        if(last)
          last->next = cur;
        else
          n->enclosures = cur;
      } else {
        last = cur;
        cur = cur->next;
      }
    }
    MuOptSTEChain temp(n->enclosures);
    chain.clear();
    chain.splice(chain.end(), temp.chain());
  } else {
    n->enclosures = NULL;
    chain.clear();
  }

  // now that the enclosures have been updated, update the hardcoded
  // size parameter so that the magic loop constants work
  // <rant>Why is this put into a variable????  If they have a
  // built-in method to compute it, why not just call the damn method
  // in cpp_code.C rather than using the variable???  Public variables
  // are evil and should never be used except under very extraordinary
  // circumstances, and then only with great care.</rant>
  // We also need to update the indep_card parameter.  In theory, if
  // I've optimized things correctly, the new indep_card should always
  // be 1.  (I have no idea why asking the appropriate Murphi code to
  // recompute it doesn't come up with 1, but maybe this will become
  // clear to me in time.)
  int newsize = n->CountSize(n->enclosures);
  if(newsize != n->size || n->indep_card != 1) {
    cout << "cleanup:      updating magic loop constants for rule \""
         << name() << "\"\n";
    n->size = newsize;
    n->indep_card = 1;
  }
}

void MuOptRuleSimple::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRule" << typeName() << "::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "ruleclass is " << typeName();
  if(name())
    out << " (" << name() << ")";
  out << "\n";
  indentLine(out, indent + 1);
  out << "enclosures\n";
  _enclosures.displayTree(out, indent + 2);
  if(type() != Startstate) {
    indentLine(out, indent + 1);
    out << "condition\n";
    _condition.displayTree(out, indent + 2);
  }
  if(type() != Invar) {
    indentLine(out, indent + 1);
    out << "locals\n";
    _locals.displayTree(out, indent + 2);
    indentLine(out, indent + 1);
    out << "body\n";
    _body.displayTree(out, indent + 2);
  }
  if(_unfair) {
    indentLine(out, indent + 1);
    out << "unfair\n";
  }
}

ScopeSet *MuOptRuleSimple::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRule" << typeName() << "::deps(uint=0) const\n";
#endif
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  result = new ScopeSet;

  if(depLoop(reqNum))
    return result;

  // HACK: these conditions on type() are ugly, should polymorph
  if(type() != Startstate) {
    temp = _condition.deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

 // HACK: these conditions on type() are ugly, should polymorph
  if(type() != Invar) {
    temp = _locals.deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;

    temp = _body.deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}

MuOptRuleStartstate::MuOptRuleStartstate(startstate *n)
  : MuOptRuleSimple(dynamic_cast<simplerule*>(n), Startstate) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleStartstate::MuOptRuleStartstate(simplerule*)\n";
#endif
}

MuOptRuleStartstate::~MuOptRuleStartstate() {
}

const char *MuOptRuleStartstate::typeName() const {
  return "Startstate";
}

MuOptRuleInvar::MuOptRuleInvar(invariant *n)
  : MuOptRuleSimple(dynamic_cast<simplerule*>(n), Invar) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleInvar::MuOptRuleInvar(simplerule*)\n";
#endif
}

MuOptRuleInvar::~MuOptRuleInvar() {
}

const char *MuOptRuleInvar::typeName() const {
  return "Invar";
}

MuOptRuleQuant::MuOptRuleQuant(quantrule *n)
  : MuOptRule(Quant, (n && n->quant && n->quant->name
                      ? n->quant->name->getname() : NULL), n),
    _quant(n ? n->quant : NULL), _rules(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleQuant::MuOptRuledQuant(quantrule*)\n";
#endif
  _rules = new MuOptRuleList(n ? n->rules : NULL);
  assert(_rules);
}

MuOptRuleQuant::~MuOptRuleQuant() {
  //delete _rules;
}

void MuOptRuleQuant::rebuildRuleInfo(const ScopeSet *encl) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleQuant::rebuildRuleInfo(const ScopeSet*)\n";
#endif
  ScopeSet newencl;
  if(encl)
    newencl.insert(encl->begin(), encl->end());
  newencl.insert(scope());
  _rules->rebuildRuleInfo(&newencl);
}

void MuOptRuleQuant::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleQuant::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "ruleclass is Quant\n";
  indentLine(out, indent + 1);
  out << "quant\n";
  _quant.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "rules\n";
  _rules->displayTree(out, indent + 2);
}

ScopeSet *MuOptRuleQuant::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleQuant::deps(uint=0) const\n";
#endif

  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _quant.deps(reqNum);

  temp = _rules->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

OptRet MuOptRuleQuant::optimize() {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleQuant::optimize()\n";
#endif
  OptRet result, rtmp;
  ScopeSet *temp;

  result.node = NULL;
  result.obj = NULL;

  // if _rules is a list, turn me into a list containing multiple
  // quant rules with only a single rule in each of their _rules
  do {
    if(_rules->isList()) {
      int size = dynamic_cast<MuOptRuleList*>(_rules)->size();
      cout << "pseudo-opt:   ruleset \"" << name() << "\" (scope "
           << scope() << ") ";
      if(size > 1)
        cout << "dividing into " << size << " branches\n";
      else
        cout << "rules list has single member, extracting\n";
      MuOptRuleList *newlist = new MuOptRuleList();
      assert(newlist);
      MuOptRule *car;
      MuOptRuleList *cdr = dynamic_cast<MuOptRuleList*>(_rules);
      assert(cdr);
      while(cdr) {
        cdr->split(car, cdr);
        if(car) { // SLOPPY
          MuOptRuleQuant *twin = new MuOptRuleQuant(*this);
          twin->_rules = car;
          rtmp = twin->optimize();
          if(rtmp.obj != NULL)
            if(dynamic_cast<MuOptRule*>(rtmp.obj))
              newlist->append(dynamic_cast<MuOptRule*>(rtmp.obj));
            else if(dynamic_cast<MuOptRuleList*>(rtmp.obj))
              newlist->append(dynamic_cast<MuOptRuleList*>(rtmp.obj));
            else
              assert(0);
          else
            newlist->append(twin);
        }
      }
      result.node = NULL;
      result.obj = newlist;
      return result;
    } else {
      rtmp = _rules->optimize();
      if(rtmp.obj != NULL)
        if(dynamic_cast<MuOptRuleBase*>(rtmp.obj))
          _rules = dynamic_cast<MuOptRuleBase*>(rtmp.obj);
        else
          assert(0);
    }
  } while(_rules->isList());

  // if remaining rule is not dependent on us, commit suicide
  temp = _rules->deps();
  if(temp->find(scope()) == temp->end()) {
    cout << "optimization: ruleset \"" << name() << "\" (scope "
         << scope() << ") with no dependencies, removing\n";
    // delete myself
    MuOptRule *myrule = dynamic_cast<MuOptRule*>(_rules);
    if(myrule) {
      result.node = myrule->node();
      result.obj = myrule;
    }
  }

  return result;
}


MuOptRuleChoose::MuOptRuleChoose(chooserule *n)
  : MuOptRule(Choose, (n && n->index && n->index->name
                       ? n->index->name->getname() : NULL), n),
    _index(n ? n->index : NULL), _set(NULL), _rules(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleChoose::MuOptRuledChoose(chooserule*)\n";
#endif
  _set = MuOptDesignator::newMuOptDesignator(n ? n->set : NULL);
  assert(_set);
  _rules = new MuOptRuleList(n ? n->rules : NULL);
  assert(_rules);
}

MuOptRuleChoose::~MuOptRuleChoose() {
  //delete _rules;
}

void MuOptRuleChoose::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleChoose::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "ruleclass is Choose\n";
  indentLine(out, indent + 1);
  out << "index\n";
  _index.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "set\n";
  _set->displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "rules\n";
  _rules->displayTree(out, indent + 2);
}

ScopeSet *MuOptRuleChoose::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleChoose::deps(uint=0) const\n";
#endif
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _index.deps(reqNum);

  temp = _set->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _rules->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

void MuOptRuleChoose::rebuildRuleInfo(const ScopeSet *encl) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleChoose::rebuildRuleInfo(const ScopeSet*)\n";
#endif
  ScopeSet newencl;
  if(encl)
    newencl.insert(encl->begin(), encl->end());
  newencl.insert(scope());
  _rules->rebuildRuleInfo(&newencl);
}

OptRet MuOptRuleChoose::optimize() {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleChoose::rebuildRuleInfo(const ScopeSet*)\n";
#endif
  OptRet result, rtmp;
  ScopeSet *temp;

  result.node = NULL;
  result.obj = NULL;

  // if _rules is a list, turn me into a list containing multiple
  // choose rules with only a single rule in each of their _rules
  do {
    if(_rules->isList()) {
      int size = dynamic_cast<MuOptRuleList*>(_rules)->size();
      cout << "pseudo-opt:   choose \"" << name() << "\" (scope "
           << scope() << ") ";
      if(size > 1)
        cout << "dividing into " << size << " branches\n";
      else
        cout << "rules list has single member, extracting\n";
      MuOptRuleList *newlist = new MuOptRuleList();
      assert(newlist);
      MuOptRule *car;
      MuOptRuleList *cdr = dynamic_cast<MuOptRuleList*>(_rules);
      assert(cdr);
      while(cdr) {
        cdr->split(car, cdr);
        if(car) { // SLOPPY
          MuOptRuleChoose *twin = new MuOptRuleChoose(*this);
          twin->_rules = car;
          rtmp = twin->optimize();
          if(rtmp.obj != NULL)
            if(dynamic_cast<MuOptRule*>(rtmp.obj))
              newlist->append(dynamic_cast<MuOptRule*>(rtmp.obj));
            else if(dynamic_cast<MuOptRuleList*>(rtmp.obj))
              newlist->append(dynamic_cast<MuOptRuleList*>(rtmp.obj));
            else
              assert(0);
          else
            newlist->append(twin);
        }
      }
      result.node = NULL;
      result.obj = newlist;
      return result;
    } else {
      rtmp = _rules->optimize();
      if(rtmp.obj != NULL)
        if(dynamic_cast<MuOptRuleBase*>(rtmp.obj))
          _rules = dynamic_cast<MuOptRuleBase*>(rtmp.obj);
        else
          assert(0);
    }
  } while(_rules->isList());

  // if remaining rule is not dependent on us, commit suicide
  temp = _rules->deps();
  if(temp->find(scope()) == temp->end()) {
    cout << "optimization: choose \"" << name() << "\" (scope "
         << scope() << ") with no dependencies, removing\n";
    // delete myself
    MuOptRule *myrule = dynamic_cast<MuOptRule*>(_rules);
    if(myrule) {
      result.node = myrule->node();
      result.obj = myrule;
    }
  }

  return result;
}

MuOptRuleAlias::MuOptRuleAlias(aliasrule *n)
  : MuOptRule(Alias, (n && n->aliases && n->aliases->name
                      ? n->aliases->name->getname() : NULL), n),
    _aliases(n ? n->aliases : NULL), _rules(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleAlias::MuOptRuleAlias(aliasrule*)\n";
#endif
  _rules = new MuOptRuleList(n ? n->rules : NULL);
  assert(_rules);
}

MuOptRuleAlias::~MuOptRuleAlias() {
  //delete _rules;
}

void MuOptRuleAlias::rebuildRuleInfo(const ScopeSet *encl) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleAlias::rebuildRuleInfo(const ScopeSet*)\n";
#endif
  ScopeSet newencl;
  if(encl)
    newencl.insert(encl->begin(), encl->end());
  newencl.insert(_aliases.scope());
  _rules->rebuildRuleInfo(&newencl);
}

void MuOptRuleAlias::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleAlias::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "ruleclass is Alias\n";
  indentLine(out, indent + 1);
  out << "aliases\n";
  _aliases.displayTree(out, indent + 2);
  indentLine(out, indent + 1);
  out << "rules\n";
  _rules->displayTree(out, indent + 2);
}

ScopeSet *MuOptRuleAlias::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleAlias::deps(uint=0) const\n";
#endif

  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _aliases.deps(reqNum);

  temp = _rules->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

OptRet MuOptRuleAlias::optimize() {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleAlias::optimize()\n";
#endif
  OptRet result, rtmp;
  ScopeSet *temp;

  result.node = NULL;
  result.obj = NULL;

  // if _rules is a list, turn me into a list containing multiple
  // alias rules with only a single rule in each of their _rules
  do {
    if(_rules->isList()) {
      int size = dynamic_cast<MuOptRuleList*>(_rules)->size();
      cout << "pseudo-opt:   alias \"" << name() << "\" (scope "
           << scope() << ") ";
      if(size > 1)
        cout << "dividing into " << size << " branches\n";
      else
        cout << "rules list has single member, extracting\n";
      MuOptRuleList *newlist = new MuOptRuleList();
      assert(newlist);
      MuOptRule *car;
      MuOptRuleList *cdr = dynamic_cast<MuOptRuleList*>(_rules);
      assert(cdr);
      while(cdr) {
        cdr->split(car, cdr);
        if(car) {
          MuOptRuleAlias *twin = new MuOptRuleAlias(*this);
          twin->_rules = car;
          rtmp = twin->optimize();
          if(rtmp.obj != NULL)
            if(dynamic_cast<MuOptRule*>(rtmp.obj))
              newlist->append(dynamic_cast<MuOptRule*>(rtmp.obj));
            else if(dynamic_cast<MuOptRuleList*>(rtmp.obj))
              newlist->append(dynamic_cast<MuOptRuleList*>(rtmp.obj));
            else
              assert(0);
          else
            newlist->append(twin);
        }
      }
      result.node = NULL;
      result.obj = newlist;
      return result;
    } else {
      rtmp = _rules->optimize();
      if(rtmp.obj != NULL)
        if(dynamic_cast<MuOptRuleBase*>(rtmp.obj))
          _rules = dynamic_cast<MuOptRuleBase*>(rtmp.obj);
        else
          assert(0);
    }
  } while(_rules->isList());

  // if remaining rule is not dependent on us, commit suicide
  temp = _rules->deps();
  if(temp->find(scope()) == temp->end()) {
    cout << "optimization: alias \"" << name() << "\" (scope "
         << scope() << ") with no dependencies, removing\n";
    // delete myself
    MuOptRule *myrule = dynamic_cast<MuOptRule*>(_rules);
    if(myrule) {
      result.node = myrule->node();
      result.obj = myrule;
    }
  }

  return result;
}


MuOptRuleFair::MuOptRuleFair(fairness *n)
  : MuOptRule(Fair, n ? n->name : NULL, n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleFair::MuOptRuledFair(fairness*)\n";
#endif
  assert(0);
}

MuOptRuleFair::~MuOptRuleFair() {
}

void MuOptRuleFair::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleFair::displayTree(int) const\n";
#endif
}

ScopeSet *MuOptRuleFair::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleFair::deps(uint=0) const\n";
#endif

  assert(0);
  return NULL;
  /*
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
  */
}

void MuOptRuleFair::rebuildRuleInfo(const ScopeSet *encl) {
  assert(0);
}

MuOptRuleLive::MuOptRuleLive(liveness *n)
  : MuOptRule(Live, n ? n->name : NULL, n) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleLive::MuOptRuledLive(liveness*)\n";
#endif
  assert(0);
}

MuOptRuleLive::~MuOptRuleLive() {
}

void MuOptRuleLive::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleLive::displayTree(int) const\n";
#endif
}

ScopeSet *MuOptRuleLive::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleLive::deps(uint=0) const\n";
#endif

  assert(0);
  return NULL;
  /*
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = .deps(reqNum);

  temp = .deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
  */
}

void MuOptRuleLive::rebuildRuleInfo(const ScopeSet *encl) {
  assert(0);
}

MuOptRuleList::MuOptRuleList(rule *r) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleList::MuOptRuleList(rule*)\n";
#endif
  assert(r);
  while(r) {
    MuOptRule *newrule = MuOptRule::newMuOptRule(r);
    assert(newrule);
    _list.push_back(newrule);
    r = r->next;
  }
}

MuOptRuleList::MuOptRuleList(const MuOptRuleList *r) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleList::MuOptRuleList(MuOptRuleList*)\n";
#endif
  if(r)
    for(list<MuOptRule*>::const_iterator i = r->_list.begin();
        i != r->_list.end(); i++)
      _list.push_back(*i);
}

MuOptRuleList::~MuOptRuleList() {
  while(!_list.empty()) {
    delete _list.front();
    _list.pop_front();
  }
}

void MuOptRuleList::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleLive::displayTree(int) const\n";
#endif
  //indentLine(indent - 1);
  //out << "[rule list]\n";
  for(list<MuOptRule*>::const_iterator i=_list.begin();i!=_list.end();i++)
    (*i)->displayTree(out, indent);
}

ScopeSet *MuOptRuleList::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleList::deps(uint=0) const\n";
#endif

  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;

  for(list<MuOptRule*>::const_iterator i=_list.begin();i!=_list.end();i++){
    temp = (*i)->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}

OptRet MuOptRuleList::optimize() {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleList::optimize()\n";
#endif
  OptRet result, temp;
  bool modified = true;

  result.node = NULL;
  result.obj = NULL;

  while(modified) {
    modified = false;
    list<MuOptRule*>::iterator i = _list.begin();
    while(i != _list.end()) {
      temp = (*i)->optimize();
      // ignore temp.node
      if(dynamic_cast<MuOptRule*>(temp.obj)) {
        *i = dynamic_cast<MuOptRule*>(temp.obj);
        i++;
        modified = true;
      } else if(dynamic_cast<MuOptRuleList*>(temp.obj)) {
        cout <<"cleanup:      merging generated list with existing list\n";
        MuOptRuleList *sublist = dynamic_cast<MuOptRuleList*>(temp.obj);
        list<MuOptRule*>::iterator j = i, k = i;
        i++;
        _list.insert(j, sublist->_list.begin(), sublist->_list.end());
        _list.erase(k);
        modified = true;
        i = _list.end();
      } else if(temp.obj != NULL)
        assert(0);
      else
        i++;
    }
  }

  // if we only have one child, return the child and delete ourself
  if(_list.size() == 1) {
    cout << "pseudo-opt:   single member rule list -> rule\n";
    //result.node = NULL;  // no transformation necessary on the
    //                     // Murphi tree
    result.obj = _list.front();
  }

  return result;
}

bool MuOptRuleList::isList() const {
  return true;
}

void MuOptRuleList::rebuildRuleInfo(const ScopeSet *encl) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRuleList::rebuildRuleInfo(const ScopeSet*)\n";
#endif
  for(list<MuOptRule*>::const_iterator i=_list.begin();i!=_list.end();i++)
    (*i)->rebuildRuleInfo(encl);
}

void MuOptRuleList::split(MuOptRule*& car, MuOptRuleList*& cdr) const {
  if(_list.size() > 1) {
    cdr = new MuOptRuleList(this);
    car = cdr->pop_front();
  } else {
    cdr = NULL;
    if(_list.size() == 1)
      car = _list.front();
    else
      car = NULL;
  }
}

MuOptRule *MuOptRuleList::pop_front() {
  if(_list.size() > 0) {
    MuOptRule *result = _list.front();
    _list.pop_front();
    return result;
  } else
    return NULL;
}

void MuOptRuleList::append(MuOptRule *r) {
  if(r)
    _list.push_back(r);
}

void MuOptRuleList::append(const MuOptRuleList *rl) {
  if(rl)
    _list.insert(_list.end(), rl->_list.begin(), rl->_list.end());
}
