// mu_opt_base.cc    -*- c++ -*-

#include "mu_opt_base.h"

uint MuOptObject::_thisReqNum = 0;

MuOptObject::MuOptObject(const char *name) {
  if(name) {
    _name = new char [strlen(name) + 1];
    strcpy(_name, name);
  } else
    _name = NULL;

  _lastReqNum = 0;
}

MuOptObject::~MuOptObject() {
  delete [] _name;
}

int MuOptObject::depLoop(uint reqNum) const {
  if(reqNum == _lastReqNum)
    return 1;
  _lastReqNum = reqNum;
  return 0;
}

void MuOptObject::indentLine(ostream& out, uint indent) {
  for(uint i = 0; i < indent; i++)
    out << "  ";
}

OptRet MuOptObject::optimize() {
  //assert(0);  // eventually I want to make this purely virtual
  OptRet result;

  result.node = NULL;
  result.obj = NULL;

  return result;
}
