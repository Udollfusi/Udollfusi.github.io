// mu_opt_root.cc    -*- c++ -*-

#include "mu_opt_root.h"
#include <fstream.h>


MuOptRoot::MuOptRoot(program *p)
  : _prog(p), _globals(NULL), _procedures(NULL), _rules(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptRoot::MuOptRoot(program*)\n";
#endif
  if(_prog) {
    _globals = new MuOptSTEChain(_prog->globals);
    _procedures = new MuOptSTEChain(_prog->procedures, _prog->globals);
    _rules = new MuOptRuleList(_prog->rules);
  }
}

MuOptRoot::~MuOptRoot() {
  delete _globals;
  delete _procedures;
  delete _rules;
}

void MuOptRoot::displayTree(ostream& out = cout) const {
  if(_prog) {
    out << "Globals:\n";
    _globals->displayTree(out, 1);
    out << "\nProcedures:\n";
    _procedures->displayTree(out, 1);
    out << "\nRules:\n";
    _rules->displayTree(out, 1);
  }
}

ScopeSet *MuOptRoot::deps() const {
  ScopeSet *result, *temp;
  uint reqNum = MuOptObject::nextReqNum();

  result = _globals->deps(reqNum);

  temp = _procedures->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _rules->deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}

void MuOptRoot::optimize() {
  OptRet or;

  // before snapshot
  /*{
    ofstream before("/tmp/before");
    assert(before.is_open());
    displayTree(before);
  }*/

  // hack some manipulations

  cout << "Optimizing rules\n";

  if(_rules) {
    or = _rules->optimize();
    assert(or.node == NULL);
    //if(or.node)
    //  _prog->rules = static_cast<rule*>(or.node);
    assert(or.obj == NULL);
    //*+*+*
    //if(dynamic_cast<MuOptRuleList*>(or.obj))
      //_rules = dynamic_cast<MuOptRuleList>(or.obj);
  }

  // Now, because the parse tree isn't actually used for rule
  // generation, we get to rebuild all sorts of other data structures
  // they are using from our hacked parse tree.  (I guess somewhere
  // along the way someone didn't understand that optimizations were
  // supposed to go in between parsing and code generation, so they
  // just hacked their nifty idea for an optimization into the parsing
  // stage.)
  simplerule::SimpleRuleList = NULL;
  _rules->rebuildRuleInfo(NULL);


  cout << "Optimization complete\n";

  // now that I'm not bothering to update the parse tree (since Murphi
  // ignores it) there isn't any point in doing the rebuild after

  // clean up and rebuild tree
  //delete _globals;
  //delete _procedures;
  //delete _rules;
  //if(_prog) {
  //  _globals = new MuOptSTEChain(_prog->globals);
  //  _procedures = new MuOptSTEChain(_prog->procedures, _prog->globals);
  //  _rules = new MuOptRuleList(_prog->rules);
  //}

  // after snapshot
  /*{
    ofstream after("/tmp/after");
    assert(after.is_open());
    displayTree(after);
  }*/
}
