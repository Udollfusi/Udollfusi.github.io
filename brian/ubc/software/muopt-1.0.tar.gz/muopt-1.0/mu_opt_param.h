// mu_opt_param.h    -*- c++ -*-

#ifndef MU_OPT_PARAM_H
#define MU_OPT_PARAM_H

#include "mu_opt_decl.h"
#include <map>

class MuOptParam : public MuOptDecl {
public:
  enum Type { Value, Var, Const, /*Name,*/ Error, unknown };

protected:
  MuOptParam(Type t, const char *name);
public:
  virtual ~MuOptParam();

  Type type() const { return _type; }

  virtual void displayTree(ostream& out, uint indent) const;

  static MuOptParam *newMuOptParam(param *);

private:
  Type _type;
  static map<param*,MuOptParam*> _existing;
};

class MuOptParamValue : public MuOptParam {
public:
  MuOptParamValue(valparam *);
  virtual ~MuOptParamValue();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  valparam *_node;  // do not own
};

class MuOptParamVar : public MuOptParam {
public:
  MuOptParamVar(varparam *);
  virtual ~MuOptParamVar();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  varparam *_node;  // do not own
};

class MuOptParamConst : public MuOptParam {
public:
  MuOptParamConst(constparam *);
  virtual ~MuOptParamConst();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  constparam *_node;  // do not own
};

/*
class MuOptParamName : public MuOptParam {
public:
  MuOptParamName(nameparam *);
  virtual ~MuOptParamName();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  nameparam *_node;  // do not own
};
*/

class MuOptParamError : public MuOptParam {
public:
  MuOptParamError(param *);
  virtual ~MuOptParamError();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  param *_node;  // do not own
};

#endif /* MU_OPT_PARAM_H */
