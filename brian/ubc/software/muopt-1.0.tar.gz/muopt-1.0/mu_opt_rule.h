// mu_opt_rule.h    -*- c++ -*-

#ifndef MU_OPT_RULE_H
#define MU_OPT_RULE_H

#include "mu_opt_base.h"
#include "mu_opt_ste.h"
#include "mu_opt_expr.h"
#include "mu_opt_stmt.h"

// bogus class so I can have a single pointer for rules and rule lists
// without going all the way up to MuOptObject
class MuOptRuleBase : public MuOptObject {
public:
  MuOptRuleBase(const char *name = NULL) : MuOptObject(name) { }
  virtual ~MuOptRuleBase();

  virtual bool isList() const = 0;
  virtual void rebuildRuleInfo(const ScopeSet *encl) = 0;
};

class MuOptRule : public MuOptRuleBase {
public:
  enum Type { Simple, Startstate, Invar, Quant, Choose, Alias,
              Fair, Live };

protected:
  MuOptRule(Type type, const char *name, rule *node) :
    MuOptRuleBase(name), _type(type), _node(node) { }
public:
  virtual ~MuOptRule();

  Type type() const { return _type; }
  rule *node() { return _node; }

  bool isList() const;

  static MuOptRule *newMuOptRule(rule*);
  static MuOptRule *newMuOptRule(MuOptRule*);

private:
  Type _type;
  rule *_node;
};

class MuOptRuleList: public MuOptRuleBase {
public:
  MuOptRuleList(rule*);
  MuOptRuleList(const MuOptRuleList* = NULL);
  virtual ~MuOptRuleList();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual OptRet optimize();
  virtual void rebuildRuleInfo(const ScopeSet *encl);

  void split(MuOptRule*& car, MuOptRuleList*& cdr) const;
  MuOptRule *pop_front();
  void append(MuOptRule* r);
  void append(const MuOptRuleList* rl);
  uint size() const { return _list.size(); }

  bool isList() const;

private:
  list<MuOptRule*> _list;
};

class MuOptRuleSimple : public MuOptRule {
public:
  MuOptRuleSimple(simplerule*);
protected:
  MuOptRuleSimple(simplerule*, Type);
public:
  virtual ~MuOptRuleSimple();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual void rebuildRuleInfo(const ScopeSet *encl);

  virtual const char *typeName() const;

private:
  MuOptSTEChain _enclosures;
  MuOptExpr     _condition;
  MuOptSTEChain _locals;
  MuOptStmtList _body;
  bool          _unfair;
};

class MuOptRuleStartstate : public MuOptRuleSimple {
public:
  MuOptRuleStartstate(startstate*);
  virtual ~MuOptRuleStartstate();

  virtual const char *typeName() const;
};

class MuOptRuleInvar : public MuOptRuleSimple {
public:
  MuOptRuleInvar(invariant*);
  virtual ~MuOptRuleInvar();

  virtual const char *typeName() const;
};

class MuOptRuleQuant : public MuOptRule {
public:
  MuOptRuleQuant(quantrule*);
  virtual ~MuOptRuleQuant();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual OptRet optimize();
  virtual void rebuildRuleInfo(const ScopeSet *encl);

  int scope() const { return _quant.scope(); }

private:
  MuOptSTE _quant;
  MuOptRuleBase *_rules;
};

class MuOptRuleChoose : public MuOptRule {
public:
  MuOptRuleChoose(chooserule*);
  virtual ~MuOptRuleChoose();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual OptRet optimize();
  virtual void rebuildRuleInfo(const ScopeSet *encl);

  int scope() const { return _index.scope(); }

private:
  MuOptSTE _index;
  MuOptDesignator *_set;
  MuOptRuleBase *_rules;
};

class MuOptRuleAlias : public MuOptRule {
public:
  MuOptRuleAlias(aliasrule*);
  virtual ~MuOptRuleAlias();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual OptRet optimize();
  virtual void rebuildRuleInfo(const ScopeSet *encl);

  int scope() const { return _aliases.scope(); }

private:
  MuOptSTE _aliases;
  MuOptRuleBase *_rules;
};

class MuOptRuleFair : public MuOptRule {
public:
  MuOptRuleFair(fairness*);
  virtual ~MuOptRuleFair();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual void rebuildRuleInfo(const ScopeSet *encl);
};

class MuOptRuleLive : public MuOptRule {
public:
  MuOptRuleLive(liveness*);
  virtual ~MuOptRuleLive();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
  virtual void rebuildRuleInfo(const ScopeSet *encl);
};

#endif /* MU_OPT_RULE_H */
