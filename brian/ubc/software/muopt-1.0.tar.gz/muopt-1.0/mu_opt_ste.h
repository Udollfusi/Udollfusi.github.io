// mu_opt_ste.h    -*- c++ -*-

#ifndef MU_OPT_STE_H
#define MU_OPT_STE_H

#include "mu_opt_base.h"

class MuOptDecl;

class MuOptSTE : public MuOptObject {
public:
  MuOptSTE(ste *s);
  virtual ~MuOptSTE();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

  int scope() const { return _scope; }

  ste *node() { return _node; }

private:
  ste *_node;  // do not own
  int _scope;
  int _lextype;
  MuOptDecl *_value;
};

class MuOptRuleSimple;  // HACK: need to do some funky stuff to Murphi side
                        //       for some of the rule optimizations *+*+*

class MuOptSTEChain : public MuOptObject {
public:
  // run from start up to but not including stop
  MuOptSTEChain(ste *start, ste *stop=NULL);
  MuOptSTEChain(stelist *start, stelist *stop=NULL);

  MuOptSTEChain(stecoll *s);
  virtual ~MuOptSTEChain();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

  ScopeSet *scopes() const;

private:
  list<MuOptSTE*>& chain() { return _chain; }
  friend MuOptRuleSimple;

private:
  list<MuOptSTE*> _chain;
};

#endif /* MU_OPT_STE_H */
