// mu_opt_typedecl.h    -*- c++ -*-

#ifndef MU_OPT_TYPEDECL_H
#define MU_OPT_TYPEDECL_H

#include "mu_opt_decl.h"
#include <map>


class MuOptTypeDecl : public MuOptDecl {
public:
  enum Type { Enum, Range, Array, MultiSet, MultiSetID, Record, Scalarset,
              Union, Error, unknown };

protected:
  MuOptTypeDecl(Type t, const char *name)
    : MuOptDecl(TypeDecl, name), _type(t) { }
public:
  virtual ~MuOptTypeDecl();

  Type type() const { return _type; }

  static MuOptTypeDecl *newMuOptTypeDecl(typedecl *);

  virtual void displayTree(ostream& out, uint indent) const;

private:
  Type _type;
  static map<typedecl*,MuOptTypeDecl*> _existing;
};

class MuOptTypeDeclEnum : public MuOptTypeDecl {
public:
  MuOptTypeDeclEnum(enumtypedecl *n);
  virtual ~MuOptTypeDeclEnum();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  enumtypedecl *_node; // do not own
  int _left;
  int _right;
  MuOptSTEChain _idvalues;
};

class MuOptTypeDeclRange : public MuOptTypeDecl {
public:
  MuOptTypeDeclRange(subrangetypedecl *n);
  virtual ~MuOptTypeDeclRange();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  subrangetypedecl *_node; // do not own
  int _left;
  int _right;
};

class MuOptTypeDeclArray : public MuOptTypeDecl {
public:
  MuOptTypeDeclArray(arraytypedecl *n);
  virtual ~MuOptTypeDeclArray();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  arraytypedecl *_node; // do not own
  MuOptTypeDecl *_indexType;
  MuOptTypeDecl *_elementType;
};

class MuOptTypeDeclMultiSet : public MuOptTypeDecl {
public:
  MuOptTypeDeclMultiSet(multisettypedecl *n);
  virtual ~MuOptTypeDeclMultiSet();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  multisettypedecl *_node; // do not own
};

class MuOptTypeDeclMultiSetID : public MuOptTypeDecl {
public:
  MuOptTypeDeclMultiSetID(multisetidtypedecl *n);
  virtual ~MuOptTypeDeclMultiSetID();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  multisetidtypedecl *_node; // do not own
};

class MuOptTypeDeclRecord : public MuOptTypeDecl {
public:
  MuOptTypeDeclRecord(recordtypedecl *n);
  virtual ~MuOptTypeDeclRecord();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  recordtypedecl *_node; // do not own
  MuOptSTEChain _fields;
};

class MuOptTypeDeclScalarset : public MuOptTypeDecl {
public:
  MuOptTypeDeclScalarset(scalarsettypedecl *n);
  virtual ~MuOptTypeDeclScalarset();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  scalarsettypedecl *_node; // do not own
  int _left;
  int _right;
  MuOptSTE _idvalues; // *+*+* should this be a chain?
};

class MuOptTypeDeclUnion : public MuOptTypeDecl {
public:
  MuOptTypeDeclUnion(uniontypedecl *n);
  virtual ~MuOptTypeDeclUnion();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  uniontypedecl *_node; // do not own
  MuOptSTEChain _unionmembers;
};

class MuOptTypeDeclError : public MuOptTypeDecl {
public:
  MuOptTypeDeclError(errortypedecl *n);
  virtual ~MuOptTypeDeclError();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  errortypedecl *_node; // do not own
};

#endif /* MU_OPT_TYPEDECL_H */
