// mu_opt_stmt.h    -*- c++ -*-

#ifndef MU_OPT_STMT_H
#define MU_OPT_STMT_H

#include "mu_opt_base.h"
#include "mu_opt_expr.h"
#include <map>

class MuOptStmt : public MuOptObject {
public:
  enum Type { Assignment, While, If, Case, Switch, For, Proc, Clear, Error,
              Assert, Put, Alias, Aliasstmt, Return, Undefine, MultisetAdd,
              MultisetRemove, Null, unknown };

protected:
  MuOptStmt(Type t) : _type(t) { }
public:
  virtual ~MuOptStmt();

  Type type() const { return _type; }

  static MuOptStmt *newMuOptStmt(stmt *);

private:
  Type _type;
  static map<stmt*,MuOptStmt*> _existing;
};

class MuOptStmtList : public MuOptObject {
public:
  MuOptStmtList(stmt *s);
  virtual ~MuOptStmtList();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  list<MuOptStmt*> _list;
};

class MuOptStmtAssignment : public MuOptStmt {
public:
  MuOptStmtAssignment(assignment *a);
  virtual ~MuOptStmtAssignment();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  assignment *_node;  // do not own
  MuOptExpr _src;
  MuOptDesignator *_target;
};

class MuOptStmtWhile : public MuOptStmt {
public:
  MuOptStmtWhile(whilestmt *w);
  virtual ~MuOptStmtWhile();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  whilestmt *_node;  // do not own
  MuOptExpr _test;
  MuOptStmtList _body;
};

class MuOptStmtIf : public MuOptStmt {
public:
  MuOptStmtIf(ifstmt *i);
  virtual ~MuOptStmtIf();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  ifstmt *_node;  // do not own
  MuOptExpr _test;
  MuOptStmtList _body;
  MuOptStmtList _else;
};

class MuOptStmtCase : public MuOptStmt {
public:
  MuOptStmtCase(caselist *c);
  virtual ~MuOptStmtCase();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  caselist *_node;  // do not own
  MuOptExprList _values;
  MuOptStmtList _body;
};

class MuOptStmtCaseList : public MuOptObject {
public:
  MuOptStmtCaseList(caselist *c);
  virtual ~MuOptStmtCaseList();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  list<MuOptStmtCase*> _list;
};

class MuOptStmtSwitch : public MuOptStmt {
public:
  MuOptStmtSwitch(switchstmt *s);
  virtual ~MuOptStmtSwitch();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  switchstmt *_node;  // do not own
  MuOptExpr _expr;
  MuOptStmtCaseList _cases;
  MuOptStmtList _default;
};

class MuOptStmtFor : public MuOptStmt {
public:
  MuOptStmtFor(forstmt *f);
  virtual ~MuOptStmtFor();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  forstmt *_node;  // do not own
  MuOptSTEChain _index;
  MuOptStmtList _body;
};

class MuOptStmtProc : public MuOptStmt {
public:
  MuOptStmtProc(proccall *p);
  virtual ~MuOptStmtProc();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  proccall *_node;  // do not own
  MuOptSTE _procedure;
  MuOptExprList _actuals;
};

class MuOptStmtClear : public MuOptStmt {
public:
  MuOptStmtClear(clearstmt *c);
  virtual ~MuOptStmtClear();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  clearstmt *_node;  // do not own
  MuOptDesignator *_target;
};

class MuOptStmtError : public MuOptStmt {
public:
  MuOptStmtError(errorstmt *e);
protected:
  MuOptStmtError(errorstmt *e, bool isAssert);
public:
  virtual ~MuOptStmtError();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

protected:
  const char *errstring() const { return _string; }

private:
  errorstmt *_node;  // do not own
  const char *_string;  // do not own
};

class MuOptStmtAssert : public MuOptStmtError {
public:
  MuOptStmtAssert(assertstmt *a);
  virtual ~MuOptStmtAssert();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  assertstmt *_node;  // do not own
  MuOptExpr _test;
};

class MuOptStmtPut : public MuOptStmt {
public:
  MuOptStmtPut(putstmt *p);
  virtual ~MuOptStmtPut();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  putstmt *_node;  // do not own
};

class MuOptStmtAlias : public MuOptStmt {
public:
  MuOptStmtAlias(alias *a);
  virtual ~MuOptStmtAlias();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  alias *_node;  // do not own
};

class MuOptStmtAliasstmt : public MuOptStmt {
public:
  MuOptStmtAliasstmt(aliasstmt *a);
  virtual ~MuOptStmtAliasstmt();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  aliasstmt *_node;  // do not own
  MuOptSTEChain _aliases;
  MuOptStmtList _body;
};

class MuOptStmtReturn : public MuOptStmt {
public:
  MuOptStmtReturn(returnstmt *r);
  virtual ~MuOptStmtReturn();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  returnstmt *_node;  // do not own
  MuOptExpr _retexpr;
};

class MuOptStmtUndefine : public MuOptStmt {
public:
  MuOptStmtUndefine(undefinestmt *u);
  virtual ~MuOptStmtUndefine();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  undefinestmt *_node;  // do not own
  MuOptDesignator *_target;
};

class MuOptStmtMultisetAdd : public MuOptStmt {
public:
  MuOptStmtMultisetAdd(multisetaddstmt *m);
  virtual ~MuOptStmtMultisetAdd();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  multisetaddstmt *_node;  // do not own
  MuOptDesignator *_element;
  MuOptDesignator *_target;
};

class MuOptStmtMultisetRemove : public MuOptStmt {
public:
  MuOptStmtMultisetRemove(multisetremovestmt *m);
  virtual ~MuOptStmtMultisetRemove();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;

private:
  multisetremovestmt *_node;  // do not own
  MuOptSTE _index;
  MuOptDesignator *_target;
  MuOptExpr _criterion;
};

class MuOptStmtNull : public MuOptStmt {
public:
  MuOptStmtNull();
  virtual ~MuOptStmtNull();

  virtual void displayTree(ostream& out, uint indent) const;
  virtual ScopeSet *deps(uint reqNum = 0) const;
};

#endif /* MU_OPT_STMT_H */
