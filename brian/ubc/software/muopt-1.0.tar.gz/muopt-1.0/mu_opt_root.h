// mu_opt_root.h    -*- c++ -*-

#ifndef MU_OPT_ROOT_H
#define MU_OPT_ROOT_H

#include "mu_opt_base.h"
#include "mu_opt_ste.h"
#include "mu_opt_rule.h"

class MuOptRoot {
public:
  MuOptRoot(program *prog);
  virtual ~MuOptRoot();

  void displayTree(ostream& out = cout) const;
  ScopeSet *deps() const;

  void optimize();

private:
  program *_prog;  // do not own
  MuOptSTEChain *_globals;
  MuOptSTEChain *_procedures;
  MuOptRuleList *_rules;
};

#endif /* MU_OPT_ROOT_H */
