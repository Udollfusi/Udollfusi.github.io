// mu_opt_expr.cc    -*- c++ -*-

#include "mu_opt_expr.h"


MuOptExpr::MuOptExpr(expr *e) : _node(e), _used(NULL) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptExpr::MuOptExpr(expr*)\n";
#endif
  _used = new MuOptSTEChain(_node ? _node->used_stes() : NULL);
  assert(_used);
}

MuOptExpr::~MuOptExpr() {
  //delete _used;
}

void MuOptExpr::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptExpr::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "[expr]\n";
  _used->displayTree(out, indent + 1);
}

ScopeSet *MuOptExpr::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptExpr::deps(uint=0)\n";
#endif
  ScopeSet *result;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = _used->deps(reqNum);

  //cout << "Expr::deps():";
  //for(ScopeSet::const_iterator i=result->begin(); i!=result->end(); i++)
  //  cout << " " << *i;
  //cout << "\n";

  return result;
}

MuOptDesignator::~MuOptDesignator() {
}

MuOptDesignator *MuOptDesignator::newMuOptDesignator(designator *d) {
    if(!d || d->left)
      // list
      return new MuOptDesignatorList(d);
    else
      // not a list
      return new MuOptDesignatorInstance(d);
}

MuOptDesignatorInstance::MuOptDesignatorInstance(designator *d)
  : MuOptExpr(d), _origin(d->origin), _arrayref(d->arrayref),
  _fieldref(d->fieldref) {
#ifdef MUOPT_DEBUG
  cerr<<"MuOptDesignatorInstance::MuOptDesignatorInstance(designator*)\n";
#endif
}

MuOptDesignatorInstance::~MuOptDesignatorInstance() {
}

bool MuOptDesignatorInstance::isList() const {
  return false;
}

void MuOptDesignatorInstance::displayTree(ostream& out, uint indent) const{
  MuOptExpr::displayTree(out, indent);
}

ScopeSet *MuOptDesignatorInstance::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDesignatorInstance::deps(uint=0)\n";
#endif
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = MuOptExpr::deps(reqNum);

  temp = _origin.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _arrayref.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  temp = _fieldref.deps(reqNum);
  result->insert(temp->begin(), temp->end());
  delete temp;

  return result;
}


MuOptExprList::MuOptExprList(exprlist *e) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptExprList::MuOptExprList(exprlist*)\n";
#endif
  while(e) {
    if(e->e) {
      MuOptExpr *n = new MuOptExpr(e->e);
      if(n)
        _list.push_back(n);
    }
    e = e->next;
  }
}

MuOptExprList::~MuOptExprList() {
  while(! _list.empty()) {
    //delete _list.front();
    _list.pop_front();
  }
}

void MuOptExprList::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptExprList::displayTree(int) const\n";
#endif
  indentLine(out, indent);
  out << "[exprlist]\n";
  for(list<MuOptExpr*>::const_iterator i=_list.begin();i!=_list.end();i++)
    (*i)->displayTree(out, indent + 1);
}

ScopeSet *MuOptExprList::deps(uint reqNum = 0) const {
  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;
  for(list<MuOptExpr*>::const_iterator i=_list.begin();i!=_list.end();i++){
    temp = (*i)->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}

MuOptDesignatorList::MuOptDesignatorList(designator *d) {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDesignatorList::MuOptDesignatorList(designator*)\n";
#endif
  assert(d);
  while(d) {
    MuOptDesignatorInstance *newdesig = new MuOptDesignatorInstance(d);
    assert(newdesig);
    _list.push_back(newdesig);
    d = d->left;
  }
}

MuOptDesignatorList::~MuOptDesignatorList() {
  while(!_list.empty()) {
    delete _list.front();
    _list.pop_front();
  }
}

bool MuOptDesignatorList::isList() const {
  return true;
}

void MuOptDesignatorList::displayTree(ostream& out, uint indent) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDesignatorList::displayTree(ostream&,uint) const\n";
#endif
  //indentLine(indent - 1);
  //out << "[designator list]\n";
  for(list<MuOptDesignatorInstance*>::const_iterator i=_list.begin();
      i!=_list.end(); i++)
    (*i)->displayTree(out, indent);
}

ScopeSet *MuOptDesignatorList::deps(uint reqNum = 0) const {
#ifdef MUOPT_DEBUG
  cerr << "MuOptDesignatorList::deps(uint=0) const\n";
#endif

  ScopeSet *result, *temp;

  if(reqNum == 0)
    reqNum = nextReqNum();

  if(depLoop(reqNum))
    return new ScopeSet;

  result = new ScopeSet;

  for(list<MuOptDesignatorInstance*>::const_iterator i=_list.begin();
      i!=_list.end(); i++) {
    temp = (*i)->deps(reqNum);
    result->insert(temp->begin(), temp->end());
    delete temp;
  }

  return result;
}
